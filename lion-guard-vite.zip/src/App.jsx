function App() {
  return <h1>Lion Guard: We Hunt Down Fake Reviews.</h1>;
}

export default App;